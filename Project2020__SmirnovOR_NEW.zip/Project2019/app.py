from flask import Flask, request, render_template
from views import page1P
app=Flask(__name__)
app.add_url_rule('/', view_func=page1P.f1, methods=['GET','POST'])
if __name__=="__main__":
    app.run()
