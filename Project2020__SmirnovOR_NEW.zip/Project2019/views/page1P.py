from flask import Flask, request, render_template
import re


def analtext(text):
  text=text.split()
  nl=0
  text_new=[]
  for word in text:
    w=""
    for i in word:
      if i.isalpha():
        w=w+i.lower()
        nl=nl+1
    if w:
      text_new.append(w)
  nw=len(text_new)
  if nw<30:
    return 0,0
  alenw=nl/nw
  t1=[]
  for i in range(0,nw-15):
    t1.append([(len(text_new[i]+text_new[i+1]+text_new[i+2]+text_new[i+3]+text_new[i+4]+text_new[i+5]+text_new[i+6]+text_new[i+7]+text_new[i+8]+text_new[i+9]+text_new[i+10]+text_new[i+11]+text_new[i+12]+text_new[i+13]+text_new[i+14]+text_new[i+15])-alenw*16),i])

  t1.sort()
  return  (text_new[t1[0][1]]+" "+text_new[t1[0][1]+1]+" "+text_new[t1[0][1]+2]+" "+text_new[t1[0][1]+3]+" "+text_new[t1[0][1]+4]+" "+text_new[t1[0][1]+5]+" "+text_new[t1[0][1]+6]+" "+text_new[t1[0][1]+7]+" "+text_new[t1[0][1]+8]+" "+text_new[t1[0][1]+9]+" "+text_new[t1[0][1]+10]+" "+text_new[t1[0][1]+11]+" "+text_new[t1[0][1]+12]+" "+text_new[t1[0][1]+13]+" "+text_new[t1[0][1]+14]+" "+text_new[t1[0][1]+15]), nw

def time_text(time,nw):
  return nw/16*(time-0.3)


def f1():
  global nw
  text = request.form.get('text')
  time = request.form.get('time')
  if text:
    if len(text.split())<30:
      return render_template("page1H.html", test0=1)
    str1, nw = analtext(text)
    return render_template("page1H.html", str1=str1)
  if time:
    if not(re.sub(r"[.]","",time).isdigit()) or len(time)-len(re.sub(r"[.]","",time))>1:
      return render_template("page1H.html", test1=1)
    timeAll = int(time_text(float(time), nw))
    return render_template("page1H.html", timeAll=timeAll,timeAll1=round(timeAll/60,1))

  return render_template("page1H.html")

